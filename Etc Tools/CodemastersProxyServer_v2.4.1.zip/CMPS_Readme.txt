CMPS.exe (Codemasters Proxy Server),  
OutGauge Proxy Server for Codemasters games 
(F1 2010, F1 2011, F1 2012, F1 2013, F1 2014, F1 2015, DiRT2, DiRT3 1.1, GRID2, GRID Autosport, DiRT Rally)
(c)2012-2015 by Zappadoc - All Rights Reserved.

This server will get around the limitation of Codemasters games to manage more than one OutGauge app/device.
This server get connected to CM game with a main OutGauge port ( #20777) and dispatch outgauge data to all
registered apps/devices (UDP ports) up to 50 devices.

The new version let you define the API version which must be used for each device udp port 
(some motion simulator manage only the standard version 1 of Codemasters API). see the example below.

***************************************************************************************
IMPORTANT FOR SLIMax Manager users: 
DON'T USE THIS PROXY for managing devices ALREADY supported by SLIMax Manager.
***************************************************************************************

INSTALLATION:
- extract archive in c:\ of your disk
- Run the Proxy Server and select the menu Options inside the application to configure the udp ports

The application is minimized at startup and the main menu is available in system-tray icon bar (bottom-right of your screen)

***************************************************************************************
IMPORTANT FOR SLIMax Manager users: 
SLIMax Manager ALREADY contains the Codemasters Poxy Server
***************************************************************************************

----------------------------------------------------------------------------------

Read the FAQ to configure your game and enable data telemetry:

http://www.eksimracing.com/f-a-q/how-to-get-codemasters-f1-20xx-dirt2-and-dirt3-working-with-latest-slimax-mgr-software/

-----------------------------------------------------------------------------------

CMPS Application (Codemasters Proxy Server) is a part of SLIMax Manager, Copyright �2012-2015 by Zappadoc - All rights reserved. 
Redistributing our software shall not be allowed without our prior written consent (send an email with a short description of your company). Downloading the application from other website shall not be allowed without our prior written consent and is NOT RECOMMENDED.

More info here:
http://www.eksimracing.com/f-a-q/

Support Forum:
http://www.eksimracing.com/forums

DISCLAIMER:
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

All product names are trademarks or registered trademarks of their respective holders.
Racing simulation software provided by Codemasters - www.codemasters.com